package org.example;

import java.util.InputMismatchException;
//esta linea importa InputMismatchException
//que me servirá para utilizar el try-catch

import java.util.Scanner;
//esto linea importa Scanner, que permite el uso
//del teclado

public class Examen {

    Scanner entrada = new Scanner(System.in);
    //esta linea permite la entrada por teclado


    public void ejercicio1() {
    //este es el primer metodo

        int aux = 1; //creo la variable aux para salir del while
        int num = 1; //creo la variable num

        System.out.println("Introduce un número:");
        //pido número
        //esto lo tenía dentro del try, lo he sacado fuera para que no muestre por pantalla
        //Introduce un número y Error. Introduce un valor valido cada vez que pongamos un valor
        //no válido

        while (aux == 1) {
        //el while me sirve para crear un bucle y que mediante el try-catch
        //el programa pida un número hasta que se introduzca un valor válido

            try {

                num = entrada.nextInt();
                //se asigna valor a la variable num mediante la entrada por teclado

                aux += 1; //sumo 1 a aux para salir del bucle

            } catch (NumberFormatException | InputMismatchException e) {
                //captura el error InputMismatchException

                System.out.println("ERROR. Introduce un valor válido:");
                //vuelve a pedir un número si se ha introducido un valor no válido
                entrada.nextLine();
                //lo registra
            }

        }

        if (num < 0) {
            //si el número es negativo, lo multiplico por -1 para
            //calcular su valor absoluto
            num = num * (-1);
            System.out.println("El valor absoluto es " + num);
            //lo imprimo

        }

        else {
            System.out.println("El valor absoluto es " + num);
            //si no es negativo lo imprimo
        }
    }

    public void ejercicio2() {
    //este es el segundo metodo

        int anchop=-1;
        int altop=-1;

        int anchoa=-1;
        int altoa=-1;

        String nombre;

        System.out.println("Introduce tu nombre:");
        nombre = entrada.next();
        System.out.println("La obra de " + nombre);
        //estas lineas piden el nombre del usuario y lo imprimen por pantalla

        //creo las variables anchop,altop,anchoa,altoa
        //les asigno -1 para que entre en el while directamente

        while(anchop<=0||altop<=0||anchoa<=0||altoa<=0) {
            //con este while controlo que los números no sean negativos ni 0

            try {

                System.out.println("Introduce el ancho de la pared:");
                anchop = entrada.nextInt();
                System.out.println("Introduce el largo de la pared:");
                altop = entrada.nextInt();

                System.out.println("Introduce el ancho del azulejo:");
                anchoa = entrada.nextInt();
                System.out.println("Introduce el largo del azulejo:");
                altoa = entrada.nextInt();
                //pido al usuario que introduzca el valor de todas las variables

                System.out.println("Los números introducidos no puede ser negativos ni 0.");
                //si es 0 o un num negativo, imprimo esto por pantalla

            }
            catch (NumberFormatException | InputMismatchException e) {
                //captura el error InputMismatchException

                System.out.println("ERROR. Introduce un valor válido:");
                //vuelve a pedir un número si se ha introducido un valor no válido
                entrada.nextLine();
                //lo registra
            }

        }

        int areap = anchop*altop;
        //creo una variable con el area de la pared
        int areaa = anchoa*altoa;
        //creo una variable con el area de los azulejos
        int resultado=areap/areaa;
        //esto calcula el número de azulejos que se necesitan para cubrir la pared

        if (anchoa==altoa){
            System.out.println("El azulejo no puede ser cuadrado.");
        }
        //este if finaliza el programa si el azulejo es cuadrado

        else if (areaa>areap) {
            System.out.println("El azulejo no puede ser más grande que la pared.");
        }
        //este else if finaliza el programa si el azulejo es más grande que la pared

        else {
            System.out.println("Se necesitan " + resultado + " azulejos.");
        }
        //este else finaliza el programa imprimiendo por pantalla los azulejos necesarios
    }

}

