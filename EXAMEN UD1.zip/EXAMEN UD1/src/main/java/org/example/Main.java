package org.example;


public class Main {
//aquí defino la clase main, desde donde llamaré a la clase examen
//y a los métodos ejercicio1 y ejercicio2

    public static void main(String[] args) {

        Examen Examen = new Examen();
        //Examen.ejercicio1();
        Examen.ejercicio2();

    }

}

